#include<iostream>
#include<dos.h>
#include<stdlib.h>
using namespace std;

// declare the necessary variables
const char WIDTH =20, HEIGHT = 10;
unsigned char player = 'P'; //SMILIE
int posX = 1, posY = 1;
unsigned char action;
int countScore = 0;

//method declaration
void playerAction();

//object class definition
struct enemies{
char symbol;
bool active;
int x;
int y;
};

unsigned char maze[HEIGHT][WIDTH] = {
{219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219}, 	//0
{219,' ',' ',' ',' ',' ',' ',' ',219,219,' ',' ',' ',' ',' ',' ',219,219,' ',219}, 	//1
{219,' ',219,' ',219,219,219,' ',' ',' ',' ',219,219,' ',219,' ',' ',' ',' ',219}, 	//2
{219,219,' ',219,' ',219,' ',219,' ',' ',219,219,' ',' ',' ',219,' ',219,219,219}, 	//3
{219,' ',' ',' ',' ',' ',' ',' ',219,' ',219,' ',' ',219,' ',219,' ',' ',' ',219}, 	//4
{219,219,' ',219,' ',219,219,219,219,' ',219,' ',219,219,' ',219,' ',219,' ',219}, 	//5
{219,' ',' ',219,' ',' ',' ',' ',219,' ',219,' ',' ',' ',219,' ',219,219,' ',219}, 	//6
{219,' ',219,219,219,' ',219,' ',' ',' ',219,219,219,' ',' ',' ',' ',219,' ',219}, 	//7
{219,' ',' ',' ',' ',' ',219,' ',219,' ',' ',' ',' ',' ',219,219,' ',' ',' ',219}, 	//8
{219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219,219} };   	//9
//0   1   2   3   4   5   6   7   8   9   0   1   2   3   4   5   6   7   8   9

int main(){
while(action != 'Q' || action !=  'q'){
cout<<"Control your player using WASD. "<<endl;
//position the maze
maze[posX][posY] = player;
for(int y = 0; y < HEIGHT; y++){
cout<<endl;
	for(int x = 0; x<WIDTH; x++){
	cout<<maze[y][x];
	}
//1st enemy
enemies enemy1;
enemy1.symbol = 'X';
enemy1.active = true;
enemy1.x = 3;
enemy1.y = 6;
maze[enemy1.y][enemy1.x] = enemy1.symbol;

//2nd enemy
enemies enemy2;
enemy2.symbol = 'Y';
enemy2.active = true;
enemy2.x = 8;
enemy2.y = 1;
maze[enemy2.y][enemy2.x] = enemy2.symbol;

//3rd enemy
enemies enemy3;
enemy3.symbol = 'Z';
enemy3.active = true;
enemy3.x = 17;
enemy3.y = 6;
maze[enemy3.y][enemy3.x] = enemy3.symbol;
}

//call the function
playerAction();
}///loop ends
return 0;
}///main ends

///function definition
void playerAction(){
cout<<endl<<"##########################################";
cout<<endl<<"Total Score is " <<countScore<<endl;
cout<<endl<<"##########################################";
cout <<endl<<"Action: ";
cin>>action;

//set the position of a space to the earlier position
int prevposX = posX;
int prevposY = posY;
unsigned char space = {32}; //ASCII code of BLANK SPACE

//switch case to determine the action
switch(action){
case 'a':
	if(maze[posX][posY-1] != 219){
	posY--;
	countScore++;
	//cout<<posX<<','<<posY<<endl;
	//set the space
	maze[prevposX][prevposY] = space;
	}
	system("cls");
	break;
case 's':
	if(maze[posX+1][posY] != 219){
	posX++;
	countScore++;
	//cout<<posX<<','<<posY<<endl;
	//set the space
	maze[prevposX][prevposY] = space;
	}
	system("cls");
	break;
case 'w':
	if(maze[posX-1][posY] != 219){
	posX--;
	countScore++;
	//cout<<posX<<','<<posY<<endl;
	//set the space
	maze[prevposX][prevposY] = space;
	}
	system("cls");
	break;
case 'd':
	if(maze[posX][posY+1] != 219){
	posY++;
	countScore++;
	//cout<<posX<<','<<posY<<endl;
	//set the space
	maze[prevposX][prevposY] = space;
	}
	system("cls");
	break;
case 'E':
	exit(-1);
case 'e':
	exit(-1);

default:
	cout<<"Incorrect Action"<<endl;
	break;
}///switch ends
}///function ends























